qwulivoice root audio layer

Install this ZIP as a KernelSU Next / Magisk module, reboot, keep the APK installed,
and change voice/soundpad settings from the qwulivoice app. The service syncs app
settings to /data/adb/qwulivoice and /vendor/etc/qwulivoice.properties for
audioserver-side processing. The module also ships an AML-compatible .aml.sh patch.
